#include <stdio.h>
#include <stdlib.h>
#include "solutions.h"


int main() {
    solve();
    return 0 ;
}

