
int compare_formations(const void *, const void *);

int compare_interfaces(const void *, const void *);

int compare_interfaces_distance(const void *, const void *);

int compare_agenda(const void *, const void *);

int compare_penalties(const void *, const void *);
